import express from "express";
import { fileURLToPath } from "url"; // Import to get __dirname functionality
import path from "path";

const app = express();
const port = 3000;

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url); // Get the current file's full path
const __dirname = path.dirname(__filename); // Get the directory name from the file path

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, 'public')));

// Define a route to serve the main HTML page
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start the server
app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
