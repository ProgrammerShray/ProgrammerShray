function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
    return array;
}


// List of questions (without worth)
let questions = [
    {
        question: "What is the capital of India?",
        options: ["Mumbai", "New Delhi", "Kolkata", "Chennai"],
        oafl: ["Mumbai", "New Delhi", " ", " "],
        correctAnswer: "New Delhi"
    },
    {
        question: "Which planet is known as the 'Red Planet'?",
        options: ["Venus", "Jupiter", "Mars", "Saturn"],
        oafl: ["Venus", " ", "Mars", " "],
        correctAnswer: "Mars"
    },
    {
        question: "Which festival is known as the 'Festival of Lights'?",
        options: ["Holi", "Diwali", "Eid", "Christmas"],
        oafl: [" ", "Diwali", " ", "Christmas"],
        correctAnswer: "Diwali"
    },
    {
        question: "Which vitamin is known as the 'Sunshine Vitamin'?",
        options: ["Vitamin A", "Vitamin B", "Vitamin C", "Vitamin D"],
        oafl: [" ", "Vitamin B", " ", "Vitamin D"],
        correctAnswer: "Vitamin D"
    },
    {
        question: "Which gas do plants absorb from the atmosphere for photosynthesis?",
        options: ["Oxygen", "Nitrogen", "Carbon Dioxide", "Hydrogen"],
        oafl: ["Oxygen", " ", "Carbon Dioxide", " "],
        correctAnswer: "Carbon Dioxide"
    },
    {
        question: "What is the largest animal on Earth?",
        options: ["African Elephant", "Blue Whale", "Giraffe", "Great White Shark"],
        oafl: [" ", "Blue Whale", " ", "Great White Shark"],
        correctAnswer: "Blue Whale"
    },
    {
        question: "Who was the first woman to win a Nobel Prize?",
        options: ["Marie Curie", "Jane Goodall", "Mother Teresa", "Rosalind Franklin"],
        oafl: ["Marie Curie", " ", "Mother Tersa", " "],
        correctAnswer: "Marie Curie"
    },
    {
        question: "Who wrote the famous play \"Romeo and Juliet\"?",
        options: ["Charles Dickens", "Mark Twain", "William Shakespeare", "George Orwell"],
        oafl: [" ", "Mark Twain", "William Shakespeare", " "],
        correctAnswer: "William Shakespeare"
    },
    {
        question: "Which of the following is a prime number?",
        options: ["15", "16", "19", "20"],
        oafl: ["15", " ", "19", " "],
        correctAnswer: "19"
    },
    {
        question: "Which of these Indian states does not share a border with Pakistan?",
        options: ["Gujarat", "Rajasthan", "Punjab", "Madhya Pradesh"],
        oafl: [" ", " ", "Punjab", "Madhya Pradesh"],
        correctAnswer: "Madhya Pradesh"
    },
    {
        question: "Which scientist proposed the theory of General Relativity?",
        options: ["Isaac Newton", "Nikola Tesla", "Albert Einstein", "Galileo Galilei"],
        oafl: ["Issac Newton", " ", "Albert Einstein", " "],
        correctAnswer: "Albert Einstein"
    },
    {
        question: "What is the name of the world’s largest desert?",
        options: ["Sahara", "Gobi", "Arctic", "Kalahari"],
        oafl: ["Sahara", "Gobi", " ", " "],
        correctAnswer: "Sahara"
    },
    {
        question: "Which element has the chemical symbol \"Fe\"?",
        options: ["Gold", "Lead", "Iron", "Silver"],
        oafl: [" ", " ", "Iron", "Silver"],
        correctAnswer: "Iron"
    },
    {
        question: "In which year did India win its first Cricket World Cup?",
        options: ["1983", "1987", "1996", "2003"],
        oafl: ["1983", " ", "1996", " "],
        correctAnswer: "1983"
    },
    {
        question: "Which Indian mathematician is known for his contributions to number theory and infinite series?",
        options: ["Srinivasa Ramanujan", "C.R. Rao", "Aryabhata", "Harish-Chandra"],
        oafl: ["Srinivasa Ramanujan", " ", "Aryabhata", " "],
        correctAnswer: "Srinivasa Ramanujan"
    },
    {
        question: "Who is credited with the invention of the World Wide Web?",
        options: ["Bill Gates", "Tim Berners-Lee", "Steve Jobs", "Larry Page"],
        oafl: ["Bill Gates", "Tim Berners-Lee", " ", " "],
        correctAnswer: "Tim Berners-Lee"
    },
    {
        question: "The famous painting \"Starry Night\" was painted by which artist?",
        options: ["Pablo Picasso", "Claude Monet", "Vincent van Gogh", "Leonardo da Vinci"],
        oafl: ["Pablo Picasso", " ", "Vincent van Gogh", " "],
        correctAnswer: "Vincent van Gogh"
    }
];

// List of worth values (keep in the same order)
let worthValues = ["₹ 1,000", "₹ 2,000", "₹ 3,000", "₹ 5,000", "₹ 10,000", "₹ 20,000", "₹ 40,000", "₹ 80,000", "₹ 1,60,000", "₹ 3,20,000", "₹ 6,40,000", "₹ 12,50,000", "₹ 25,00,000", "₹ 50,00,000", "₹ 75,00,000", "₹ 1,00,00,000", "₹ 7,00,00,000"];

//List of time values (keep in the same order)
let timeValues = [45, 45, 45, 45, 45, 60, 60, 60, 60, 60, "∞", "∞", "∞", "∞", "∞", "∞", "∞"]

// Selecting the prize element (optional if prize element exists on finalPrize.html)
let prizeMoney = document.querySelector(".prize");

let message = "";

let questionSound = new Audio("assets/sounds/_Kbc_Question_Sound_Effect_Notification_Ringtone_(by Fringster.com).mp3")
let clockSound = new Audio("assets/sounds/_Kbc_Clock_Ringtone_(by Fringster.com).mp3 ")


let lifelines = document.querySelector(".lifelines")

//lifelines
let fifty_fifty = document.querySelector(".fifty_fifty")
let phoneToAFriend = document.querySelector(".phoneToAFriend")
let revive = document.querySelector(".revive")


fifty_fifty.style.display = "inline"
phoneToAFriend.style.display = "inline"

let quit = document.querySelector(".quit");


function doQuit() {

    quit.addEventListener('click', () => {
        // let message;

        // Assuming 'questions' and 'questionIndex' are globally defined
        if (worthValues[questionIndex] === "₹ 1,000") {
            message = "Sorry! But You Didn't Win Anything";
        } else {
            // Display the worth from the previous question
            message = "You have won " + worthValues[questionIndex - 1];
        }

        // Store the message in localStorage so it can be accessed on the next page
        localStorage.setItem("quitMessage", message);

        // Redirect the user to the "finalPrize.html" page
        window.location.href = "finalPrize.html";
    });
}

// doQuit()


function addQuestion(questionData, worth, time) {
    let phoneUsed = false; // A flag to check if the phone-to-a-friend lifeline is already used

    doQuit()
    questionSound.play()

    let Question = document.querySelector(".question");
    let a = document.querySelector(".option1");
    let b = document.querySelector(".option2");
    let c = document.querySelector(".option3");
    let d = document.querySelector(".option4");

    Question.innerHTML = questionData.question;
    a.innerHTML = questionData.options[0];
    b.innerHTML = questionData.options[1];
    c.innerHTML = questionData.options[2];
    d.innerHTML = questionData.options[3];

    let clock = document.querySelector(".clock");
    let Time = time;

    let Worth = document.querySelector(".worth");
    Worth.innerHTML = worth;

    let intervalTime = 1000; // Interval time in milliseconds (1000ms = 1 second)

    // Clear any previous background colors
    [a, b, c, d].forEach(option => option.style.backgroundColor = "");

    fifty_fifty_lifeline()
    phoneToAFriendLifeline()
    reviveLifeline()

    function reviveLifeline(){
        revive.addEventListener('click', ()=>{
          
          
                fifty_fifty.style.filter = "none"
                fifty_fifty.style.pointerEvents = "auto"
                phoneToAFriend.style.filter = "none"
                phoneToAFriend.style.pointerEvents = "auto"
          
                revive.style.filter = "grayscale(1)"
                revive.style.pointerEvents = "none"
          }
        )
    }

    // Function to decrease the number slowly (for timer)
    let interval = setInterval(() => {
        clock.innerHTML = Time;
        Time--;

        clockSound.loop = true

        clockSound.play()

        // Stop the interval when the time reaches 0 (Timeout)
        if (Time < 0) {
            clearInterval(interval);
            console.log("Time's up!");
            showCorrectAnswer()
            clockSound.pause()
            clockSound.currentTime = 0
            // doQuit()
            handleTimeout();  // Handle timeout
        }
    }, intervalTime);

    //function of fifty_fifty lifeline
    function fifty_fifty_lifeline() {
        fifty_fifty.addEventListener('click', () => {

            //set new values based on fifty fifty lifeline
            a.innerHTML = questionData.oafl[0];
            b.innerHTML = questionData.oafl[1];
            c.innerHTML = questionData.oafl[2];
            d.innerHTML = questionData.oafl[3];

            //changing its color to show that it is now useless to click 
            fifty_fifty.style.filter = "grayscale(1)"
            fifty_fifty.style.pointerEvents = "none"

            if (a.innerHTML == " ") {
                a.removeEventListener('click', handleA)
            }

            if (b.innerHTML == " ") {
                b.removeEventListener('click', handleB)
            }

            if (c.innerHTML == " ") {
                c.removeEventListener('click', handleC)
            }

            if (d.innerHTML == " ") {
                d.removeEventListener('click', handleD)
            }
        })

    }
    // let phoneUsed = false; // Track if the lifeline has been used

    // Function to handle "Phone to a Friend" lifeline
    function phoneToAFriendLifeline() {
        if (phoneUsed) return; // If lifeline is already used, do nothing

        // Add event listener to "Phone to a Friend" button
        phoneToAFriend.addEventListener('click', function () {
            if (phoneUsed) return; // If it's used already, do nothing

            // Display the correct answer once
            alert("The correct answer is " + questions[questionIndex].correctAnswer);

            // Remove the button from the UI
            phoneToAFriend.style.filter = "grayscale(1)"
            phoneToAFriend.style.pointerEvents = "none";
            // Mark the lifeline as used
            phoneUsed = true;
        });
    }

    // Call this function once when the game starts
    phoneToAFriendLifeline();

    if (worth == "₹ 7,00,00,000") {
        removeLifelines()
    }


    //function of double dip lifeline
    // Function to handle double dip lifeline
    
    function processAnswer(optionElement) {
        clearInterval(interval); // Stop the timer
        const userAnswer = optionElement.innerHTML;

        // Check if the answer is correct
        if (userAnswer === questionData.correctAnswer) {
            optionElement.style.backgroundColor = "green"; // Mark as correct

            // Move to the next question after a short delay
            setTimeout(loadNextQuestion, 2000);
        } else {
            optionElement.style.backgroundColor = "red"; // Mark incorrect
            showCorrectAnswer();

            // Redirect to the final prize page after showing the correct answer
            setTimeout(() => finalPrize(userAnswer), 2000);
        }

        // Disable all answer buttons after one click
        a.removeEventListener("click", handleA);
        b.removeEventListener("click", handleB);
        c.removeEventListener("click", handleC);
        d.removeEventListener("click", handleD);
    }


    // Create event handler functions for each option
    function handleA() { processAnswer(a); }
    function handleB() { processAnswer(b); }
    function handleC() { processAnswer(c); }
    function handleD() { processAnswer(d); }

    // Add event listeners for each option
    a.addEventListener("click", handleA);
    b.addEventListener("click", handleB);
    c.addEventListener("click", handleC);
    d.addEventListener("click", handleD);


    // Function to handle answer clicks
   

    // Event handler functions for each answer option
    function handleA() { processAnswer(a); }
    function handleB() { processAnswer(b); }
    function handleC() { processAnswer(c); }
    function handleD() { processAnswer(d); }

    // Add event listeners to each answer option
    a.addEventListener("click", handleA);
    b.addEventListener("click", handleB);
    c.addEventListener("click", handleC);
    d.addEventListener("click", handleD);


    // Function to handle the final prize and redirect (Incorrect answer)
    function finalPrize(userAnswer) {
        const worthValue = parseInt(worth.replace("₹", "").replaceAll(",", ""));
        if (worthValue <= 10000 && userAnswer !== questionData.correctAnswer) {
            message = "Sorry! But You Didn't Win Anything :( Better Luck Next Time";
        }
        else if (worthValue > 10000 && worthValue <= 320000 && userAnswer !== questionData.correctAnswer) {
            // If worth is between ₹ 20,000 and ₹ 3,20,000, user wins ₹ 10,000 for an incorrect answer
            message = "                Congratulations! You Have Won ₹ 10,000";
        }
        else if (worthValue > 320000 && worthValue <= 7500000 && userAnswer !== questionData.correctAnswer) {
            message = "                Congratulations! You Have Won ₹ 3,20,000";
        }
        else if (worthValue > 7500000 && worthValue <= 70000000 && userAnswer !== questionData.correctAnswer) {
            message = "                Congratulations! You Have Won ₹ 75,00,000";
        }
        else if (userAnswer === questionData.correctAnswer && worthValue == 70000000) {
            // If the answer is correct, the user wins the full worth value
            message = "Congratulations! You won ₹ 7,00,00,000";
        }

        // Store the prize message in localStorage
        localStorage.setItem("prizeMessage", message);

        // Redirect to the final prize page
        window.location.assign("finalPrize.html");
    }

    // Function to handle timeout scenario
    // Function to handle timeout scenario
    function handleTimeout() {
        // let message;

        // Get the current worth value
        const worthValue = parseInt(worthValues[questionIndex].replace("₹", "").replaceAll(",", ""));

        // Determine the prize based on the worth at the time of timeout
        if (worthValue <= 10000) {
            message = "Sorry! But You Didn't Win Anything";
        } else if (worthValue > 10000 && worthValue <= 320000) {
            message = "Congratulations! You Have Won ₹ 10,000";
        } else if (worthValue > 320000 && worthValue <= 7500000) {
            message = "Congratulations! You Have Won ₹ 3,20,000";
        } else if (worthValue > 7500000 && worthValue <= 70000000) {
            message = "Congratulations! You Have Won ₹ 75,00,000";
        }
        else {
            message = "You have won ₹ " + worthValues[questionIndex];
        }

        // Store the message in localStorage so it can be accessed on the final prize page
        localStorage.setItem("prizeMessage", message);

        // Redirect the user to the "finalPrize.html" page
        setTimeout(() => {
            window.location.assign("finalPrize.html");
        }, 2000);  // 2-second delay to show the correct answer before redirecting
    }

    function removeLifelines() {
        fifty_fifty.style.pointerEvents = "none"
        fifty_fifty.style.filter = "grayscale(1)"
        
        phoneToAFriend.style.pointerEvents = "none"
        phoneToAFriend.style.filter = "grayscale(1)"
        
        revive.style.pointerEvents = "none"
        revive.style.filter = "grayscale(1)"
        
    }


    // Function to highlight the correct answer
    function showCorrectAnswer() {
        if (a.innerHTML === questionData.correctAnswer) {
            a.style.backgroundColor = "green";
        } else if (b.innerHTML === questionData.correctAnswer) {
            b.style.backgroundColor = "green";
        } else if (c.innerHTML === questionData.correctAnswer) {
            c.style.backgroundColor = "green";
        } else if (d.innerHTML === questionData.correctAnswer) {
            d.style.backgroundColor = "green";
        }
    }


    // Create event handler functions for each option
    function handleA() { processAnswer(a); }
    function handleB() { processAnswer(b); }
    function handleC() { processAnswer(c); }
    function handleD() { processAnswer(d); }

    // Add event listeners for each option
    a.addEventListener("click", handleA);
    b.addEventListener("click", handleB);
    c.addEventListener("click", handleC);
    d.addEventListener("click", handleD);
}

// Function to load the next question
function loadNextQuestion() {
    questionIndex++; // Move to the next question

    if (questionIndex < questions.length) {
        addQuestion(questions[questionIndex], worthValues[questionIndex], timeValues[questionIndex]); // Load the next question
    } else {
        // Redirect to the final prize page after the last question
        window.location.assign("finalPrize.html");
        console.log("Quiz completed!");
    }
}

shuffleArray(questions)

// Start with the first question
let questionIndex = 0; // Keep track of the current question
addQuestion(questions[questionIndex], worthValues[questionIndex], timeValues[questionIndex]);
