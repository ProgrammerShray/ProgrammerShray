let submit = document.querySelector(".submit");
let nameField = document.querySelector(".nameBox");

let introSound = new Audio("assets/sounds/Kaun Banega Crorepati.mp3")

introSound.loop = true
introSound.play()

submit.addEventListener("click", () => {
    // Use value instead of innerHTML and call .trim() as a method
    if (nameField.value.trim() === "") {
        alert("Please Fill Your Name To Proceed");
    } 
    else{
        window.location.href = "questionPage.html"
    }
});
