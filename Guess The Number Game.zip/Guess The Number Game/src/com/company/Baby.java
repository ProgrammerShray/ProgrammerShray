package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;

public class Baby {
    public JFrame Baby(){

        final JFrame frame = new JFrame("Guess The Number Game (Baby Mode)");
        frame.setVisible(true);
//        frame.setSize(200,100);
        frame.setBackground(Color.ORANGE);
        frame.setResizable(false);
        frame.setDefaultCloseOperation(frame.DISPOSE_ON_CLOSE);

//        frame.setLocationRelativeTo(new MainApp.getInstance()));

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

        JLabel heading = new JLabel("Guess The Number");
        heading.setFont(new Font("Dialog", Font.BOLD, 30));
        heading.setForeground(Color.decode(CommonColors.label));

//        final int numOfGuesses = 10;
        final JLabel guesses = new JLabel();
        guesses.setFont(new Font("Dialog", Font.BOLD, 20));
        guesses.setForeground(Color.decode(CommonColors.label2));
//        guess.add(guesses);

        mainPanel.setBackground(Color.decode(CommonColors.bg));

//        panel1.add(panel2, BorderLayout.CENTER);
        heading.setAlignmentX(Component.CENTER_ALIGNMENT);
        guesses.setAlignmentX(Component.CENTER_ALIGNMENT);

        heading.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0)); // Adjust top and bottom spacing as needed
        guesses.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0)); // Adjust top and bottom spacing as needed


        mainPanel.add(heading);
        mainPanel.add(guesses);

        //Player Panel

        final JPanel playerPanel = new JPanel();
//        playerPanel.setLayout(new BoxLayout(playerPanel, BoxLayout.Y_AXIS));
        playerPanel.setBackground(Color.decode(CommonColors.bg));

        final JLabel playerLabel = new JLabel("Enter the number between 0 to 100: ");
        playerLabel.setForeground(Color.decode(CommonColors.playerColor));
        playerLabel.setVisible(true);

        final JTextField playerinput = new JTextField();
        playerinput.setPreferredSize(new Dimension(200,30));
        playerinput.setVisible(true);
        playerinput.setDocument(new NumberDocument());

        playerinput.setForeground(Color.decode(CommonColors.playerColor));

        JButton check= new JButton("Check");
        check.setBackground(Color.decode(CommonColors.computerColor));
        check.setForeground(Color.decode(CommonColors.bg));
        check.setVisible(true);
        check.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));


        playerLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        playerinput.setAlignmentX(Component.CENTER_ALIGNMENT);
        check.setAlignmentX(Component.CENTER_ALIGNMENT);

        playerLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0)); // Adjust top and bottom spacing as needed
        check.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0)); // Adjust top and bottom spacing as needed


        playerPanel.add(playerLabel);
        playerPanel.add(playerinput);
        playerPanel.add(check);

        mainPanel.add(playerPanel);

        JPanel footerPanel = new JPanel();
        footerPanel.setBackground(Color.decode(CommonColors.bg));

        JButton hint = new JButton("Hint");
        hint.setBackground(Color.decode(CommonColors.computerColor));
        hint.setForeground(Color.decode(CommonColors.bg));
        hint.setVisible(true);
        hint.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        hint.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0)); // Adjust top and bottom spacing as needed


        JButton resign = new JButton("Resign");
        resign.setBackground(Color.decode(CommonColors.computerColor));
        resign.setForeground(Color.decode(CommonColors.bg));
        resign.setVisible(true);
        resign.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        resign.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0)); // Adjust top and bottom spacing as needed

        footerPanel.add(hint);
        footerPanel.add(resign);


        mainPanel.add(footerPanel);

        //Adding Components to the App
        frame.add(mainPanel);

//        frame.setLocationRelativeTo(new MainApp().App());


        //Writing Logic Of Backend

        Random random = new Random();
        final int compNum = random.nextInt(101);

//        final int[] remainingGuesses = {20};
        guesses.setText("You have unlimited guesses");

        check.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int playerNum = Integer.parseInt(playerinput.getText());
//                remainingGuesses[0]--;

                if (playerNum == compNum) {
                    JOptionPane.showMessageDialog(null, "Congratulations! The number that you guessed is correct: " + compNum);

                    // Dispose the Easy frame
                    frame.setVisible(false);

                    // Launch MainApp frame
                    MainApp app = new MainApp();
                    app.setVisible(true);
//                    System.exit(0);

                } else if (playerNum > compNum) {
//                    guesses.setText("You have " + remainingGuesses[0] + " guesses left");
                    JOptionPane.showMessageDialog(null, "Lower Number Must Be Entered To Win");

                } else {
//                    guesses.setText("You have " + remainingGuesses[0] + " guesses left");
                    JOptionPane.showMessageDialog(null, "Higher Number Must Be Entered To Win");
                }

                //Checks that the number of guesses is 0

                playerinput.setText(""); // Moved here to clear input after processing
            }
        });

        //Writing Logic Of Resigning
        resign.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Your Resignation is successful! The correct number is " + compNum);
                // Dispose the Easy frame
                frame.setVisible(false);

                // Launch MainApp frame
                MainApp app = new MainApp();
                app.setVisible(true);

            }
        });


        //Writing the logic of hint button
        hint.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (compNum>=0 && compNum<=10){
                    JOptionPane.showMessageDialog(null, "The Number is between 0 to 10");
                }
                else if (compNum>=10 && compNum<=20){
                    JOptionPane.showMessageDialog(null, "The Number is between 10 to 20");

                }
                 else if (compNum>=20 && compNum<=30){
                    JOptionPane.showMessageDialog(null, "The Number is between 20 to 30");

                }
                 else if (compNum>=30 && compNum<=40){
                    JOptionPane.showMessageDialog(null, "The Number is between 30 to 40");

                }
                 else if (compNum>=40 && compNum<=50){
                    JOptionPane.showMessageDialog(null, "The Number is between 40 to 50");

                }
                 else if (compNum>=50 && compNum<=60){
                    JOptionPane.showMessageDialog(null, "The Number is between 50 to 60");

                }
                 else if (compNum>=60 && compNum<=70){
                    JOptionPane.showMessageDialog(null, "The Number is between 60 to 70");

                }
                 else if (compNum>=70 && compNum<=80){
                    JOptionPane.showMessageDialog(null, "The Number is between 70 to 80");

                }
                 else if (compNum>=80 && compNum<=90){
                    JOptionPane.showMessageDialog(null, "The Number is between 80 to 90");
                }
                 else if (compNum>=90 && compNum<=100){
                    JOptionPane.showMessageDialog(null, "The Number is between 90 to 100");
                }

            }
        });


        frame.pack();

        return frame;
    }
}
