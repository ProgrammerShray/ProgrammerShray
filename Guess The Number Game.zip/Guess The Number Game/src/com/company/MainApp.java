package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainApp extends JFrame {
    private static MainApp instance = null;

    public static MainApp getInstance() {
        if (instance == null) {
            instance = new MainApp();
        }
        return instance;
    }
    public void App(){
            setTitle("Guess The Number Game");
            setVisible(true);
//        frame.setSize(200,100);
            setBackground(Color.ORANGE);
            setResizable(false);
            setDefaultCloseOperation(EXIT_ON_CLOSE);

            JPanel mainPanel = new JPanel();
            mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));

            JLabel heading = new JLabel("Guess The Number");
            heading.setFont(new Font("Dialog", Font.BOLD, 30));
            heading.setForeground(Color.decode(CommonColors.label));

//        final int numOfGuesses = 10;
            final JLabel guesses = new JLabel();
            guesses.setFont(new Font("Dialog", Font.BOLD, 20));
            guesses.setForeground(Color.decode(CommonColors.label2));
//        guess.add(guesses);

            mainPanel.setBackground(Color.decode(CommonColors.bg));

//        panel1.add(panel2, BorderLayout.CENTER);
            heading.setAlignmentX(Component.CENTER_ALIGNMENT);
            guesses.setAlignmentX(Component.CENTER_ALIGNMENT);

            heading.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0)); // Adjust top and bottom spacing as needed
            guesses.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0)); // Adjust top and bottom spacing as needed


            mainPanel.add(heading);
            mainPanel.add(guesses);

            //Adding Buttons
            JPanel difficulty = new JPanel();
            difficulty.setBackground(Color.decode(CommonColors.bg));

            JLabel choose = new JLabel("Choose The Difficulty of the game from below");
            choose.setForeground(Color.decode(CommonColors.playerColor));
            choose.setBackground(Color.decode(CommonColors.bg));
            choose.setFont(new Font("Dialog",Font.BOLD,21));

            JPanel buttons = new JPanel();
            buttons.setBackground(Color.decode(CommonColors.bg));

            JButton baby = new JButton("Baby");
            baby.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            baby.setForeground(Color.WHITE);
            baby.setBackground(Color.decode(CommonColors.baby));
            baby.setPreferredSize(new Dimension(150,80));
            baby.setFont(new Font("Dialog",Font.BOLD,20));

            JButton easy = new JButton("Easy");
            easy.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            easy.setForeground(Color.WHITE);
            easy.setBackground(Color.decode(CommonColors.easy));
            easy.setPreferredSize(new Dimension(150,80));
            easy.setFont(new Font("Dialog",Font.BOLD,20));

            JButton medium = new JButton("Medium");
            medium.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            medium.setForeground(Color.WHITE);
            medium.setBackground(Color.decode(CommonColors.medium));
            medium.setPreferredSize(new Dimension(150,80));
        medium.setFont(new Font("Dialog",Font.BOLD,20));


        JButton hard = new JButton("Hard");
            hard.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            hard.setForeground(Color.WHITE);
            hard.setBackground(Color.decode(CommonColors.hard));
            hard.setPreferredSize(new Dimension(150,80));
        hard.setFont(new Font("Dialog",Font.BOLD,20));

JButton impossible = new JButton("Impossible");
        impossible.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        impossible.setForeground(Color.WHITE);
        impossible.setBackground(Color.decode(CommonColors.impossible));
        impossible.setPreferredSize(new Dimension(150,80));
        impossible.setFont(new Font("Dialog",Font.BOLD,20));

JButton devil = new JButton("Devil");
        devil.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        devil.setForeground(Color.WHITE);
        devil.setBackground(Color.decode(CommonColors.devil));
        devil.setPreferredSize(new Dimension(150,80));
        devil.setFont(new Font("Dialog",Font.BOLD,20));


            buttons.add(baby);
            buttons.add(easy);
            buttons.add(medium);
            buttons.add(hard);
            buttons.add(impossible);
            buttons.add(devil);

            difficulty.add(choose);

            mainPanel.add(difficulty);
            mainPanel.add(buttons);
            add(mainPanel);
//            frame.add(buttons);

        //Adding backend of the selection choice

        baby.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Dispose the MainApp frame
                MainApp.getInstance().setVisible(false);

                // Open the Medium frame
                Baby baby1 = new Baby();
                JFrame babyFrame = baby1.Baby();
                babyFrame.setVisible(true);
            }
        });

        easy.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Dispose the MainApp frame
                MainApp.getInstance().setVisible(false);

                // Open the Medium frame
                Easy easy1 = new Easy();
                JFrame easyFrame = easy1.Easy();
                easyFrame.setVisible(true);
            }
        });

        medium.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Dispose the MainApp frame
                MainApp.getInstance().setVisible(false);


                // Open the Medium frame
                Medium medium1 = new Medium();
                JFrame mediumFrame = medium1.Medium();
                mediumFrame.setVisible(true);
            }
        });


        hard.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Dispose the MainApp frame
                MainApp.getInstance().setVisible(false);

                // Open the Medium frame
                Hard hard1 = new Hard();
                JFrame hardFrame = hard1.Hard();
                hardFrame.setVisible(true);
            }
        });

        impossible.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Dispose the MainApp frame
                MainApp.getInstance().setVisible(false);

                // Open the Medium frame
                Impossible impossible1 = new Impossible();
                JFrame impossibleFrame = impossible1.Impossible();
                impossibleFrame.setVisible(true);
            }
        });

        devil.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Dispose the MainApp frame
                MainApp.getInstance().setVisible(false);

                // Open the Medium frame
                Devil devil1 = new Devil();
                JFrame devilFrame = devil1.Devil();
                devilFrame.setVisible(true);
            }
        });

            pack();
            setLocationRelativeTo(null);
        }
}