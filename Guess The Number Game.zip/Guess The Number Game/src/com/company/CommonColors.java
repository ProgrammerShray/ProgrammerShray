package com.company;

public class CommonColors {
      public static String  bg = "#ffc352";
      public static String  label = "#72c329";
      public static String  label2 = "#ff1616";
      public static String  computerColor = "#414142";
      public static String  playerColor = "#00299f";
      public static String baby = "#7cff46";
      public static String easy = "#56ff54";
      public static String medium = "#efff00";
      public static String hard = "#ff0000";
      public static String impossible = "#890000";
      public static String devil = "#480000";
}
