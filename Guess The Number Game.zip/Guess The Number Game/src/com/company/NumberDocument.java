package com.company;

import javax.swing.text.*;

public class NumberDocument extends PlainDocument {
    @Override
    public void insertString(int offs, String str, AttributeSet a) throws BadLocationException {
        if (str == null) {
            return;
        }
        try {
            String currentText = getText(0, getLength());
            String newText = currentText.substring(0, offs) + str + currentText.substring(offs);
            int newValue = Integer.parseInt(newText);
            if (newValue >= 0 && newValue <= 100) {
                super.insertString(offs, str, a);
            }
        } catch (NumberFormatException | StringIndexOutOfBoundsException e) {
            // Ignore if it's not a valid number or out of bounds
        }
    }
}